/*********************************************************************
  File Information:
    FileName:        usb_function_msd.c
    Dependencies:    See INCLUDES section below
    Processor:       PIC18, PIC24, or PIC32
    Compiler:        C18, C30, or C32
    Company:         Microchip Technology, Inc.

    Software License Agreement

    The software supplied herewith by Microchip Technology Incorporated
    (the �Company�) for its PICmicro� Microcontroller is intended and
    supplied to you, the Company�s customer, for use solely and
    exclusively on Microchip PICmicro Microcontroller products. The
    software is owned by the Company and/or its supplier, and is
    protected under applicable copyright laws. All rights are reserved.
    Any use in violation of the foregoing restrictions may subject the
    user to criminal sanctions under applicable laws, as well as to
    civil liability for the breach of the terms and conditions of this
    license.

    THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
    WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
    TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
    PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
    IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
    CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.

  Summary:
    This file contains functions, macros, definitions, variables,
    datatypes, etc. that are required for use of the MSD function
    driver. This file should be included in projects that use the MSD
    \function driver.
    
    
    
    This file is located in the "\<Install Directory\>\\Microchip\\USB\\MSD
    Device Driver" directory.

  Description:
    USB MSD Function Driver File
    
    This file contains functions, macros, definitions, variables,
    datatypes, etc. that are required for use of the MSD function
    driver. This file should be included in projects that use the MSD
    \function driver.
    
    This file is located in the "\<Install Directory\>\\Microchip\\USB\\MSD
    Device Driver" directory.
    
    When including this file in a new project, this file can either be
    referenced from the directory in which it was installed or copied
    directly into the user application folder. If the first method is
    chosen to keep the file located in the folder in which it is installed
    then include paths need to be added so that the library and the
    application both know where to reference each others files. If the
    application folder is located in the same folder as the Microchip
    folder (like the current demo folders), then the following include
    paths need to be added to the application's project:
    
    ..\\Include
    
    ..\\..\\Include
    
    ..\\..\\Microchip\\Include
    
    ..\\..\\\<Application Folder\>
    
    ..\\..\\..\\\<Application Folder\>
    
    If a different directory structure is used, modify the paths as
    required. An example using absolute paths instead of relative paths
    would be the following:
    
    C:\\Microchip Solutions\\Microchip\\Include
    
    C:\\Microchip Solutions\\My Demo Application
********************************************************************/
 
/** I N C L U D E S **************************************************/
#include "Compiler.h"
#include "GenericTypeDefs.h"
#include "usb_config.h"
#include "USB/usb_device.h"
#include "USB/USB.h"
#include "HardwareProfile.h"
#include "FSConfig.h"

#include "./USB/usb_function_msd.h"

#ifdef USB_USE_MSD

#if MAX_LUN == 0
    #define LUN_INDEX 0
#else
    #define LUN_INDEX gblCBW.bCBWLUN
#endif

#if defined(__C30__) || defined(__C32__)
    #if defined(USE_INTERNAL_FLASH)
        #include "MDD File System\Internal Flash.h"
    #endif

    #if defined(USE_SD_INTERFACE_WITH_SPI)
        #include "MDD File System\SD-SPI.h"
    #endif

    extern LUN_FUNCTIONS LUN[MAX_LUN + 1];
    #define LUNMediaInitialize()                LUN[LUN_INDEX].MediaInitialize()
    #define LUNReadCapacity()                   LUN[LUN_INDEX].ReadCapacity()
    #define LUNReadSectorSize()                 LUN[LUN_INDEX].ReadSectorSize()
    #define LUNMediaDetect()                    LUN[LUN_INDEX].MediaDetect()
    #define LUNSectorWrite(bLBA,pDest,Write0)   LUN[LUN_INDEX].SectorWrite(bLBA, pDest, Write0)
    #define LUNWriteProtectState()              LUN[LUN_INDEX].WriteProtectState()
    #define LUNSectorRead(bLBA,pSrc)            LUN[LUN_INDEX].SectorRead(bLBA, pSrc)
#else	//else must be C18
    #if defined(USE_INTERNAL_FLASH)
        #include "MDD File System\Internal Flash.h"
    #endif

    #if defined(USE_SD_INTERFACE_WITH_SPI)
        #include "MDD File System\SD-SPI.h"
    #endif

    #define LUNMediaInitialize()                MDD_MediaInitialize()
    #define LUNReadCapacity()                   MDD_ReadCapacity()
    #define LUNReadSectorSize()                 MDD_ReadSectorSize()
    #define LUNMediaDetect()                    MDD_MediaDetect()
    #define LUNSectorWrite(bLBA,pDest,Write0)   MDD_SectorWrite(bLBA, pDest, Write0)
    #define LUNWriteProtectState()              MDD_WriteProtectState()
    #define LUNSectorRead(bLBA,pSrc)            MDD_SectorRead(bLBA, pSrc)
#endif

/** V A R I A B L E S ************************************************/
#pragma udata
BYTE MSD_State;			// Takes values MSD_WAIT, MSD_DATA_IN or MSD_DATA_OUT
USB_MSD_CBW gblCBW;	
BYTE gblCBWLength;
RequestSenseResponse gblSenseData[MAX_LUN + 1];
BYTE *ptrNextData;
USB_HANDLE USBMSDOutHandle;
USB_HANDLE USBMSDInHandle;
WORD MSBBufferIndex;
WORD gblMediaPresent; 
static BYTE MSDCommandState;
BOOL ClearSTALLBlocked;
BYTE MSDWriteState;
BYTE MSDReadState;
BOOL SkipMSD_SEND_CSWState;
BOOL HostNoData;

static WORD_VAL TransferLength;
static DWORD_VAL LBA;

/* 
 * Number of Blocks and Block Length are global because 
 * for every READ_10 and WRITE_10 command need to verify if the last LBA 
 * is less than gblNumBLKS	
 */	
DWORD_VAL gblNumBLKS,gblBLKLen;	
extern const ROM InquiryResponse inq_resp;

/** P R I V A T E  P R O T O T Y P E S ***************************************/
BYTE MSDProcessCommand(void);
BYTE MSDReadHandler(void);
BYTE MSDWriteHandler(void);
void ResetSenseData(void);
void MSDStatesInit(void);

/** D E C L A R A T I O N S **************************************************/
#pragma code

/** C L A S S  S P E C I F I C  R E Q ****************************************/

/******************************************************************************
  Function:
    void USBMSDInit(void)
    
  Summary:
    This routine initializes the MSD class packet handles, prepares to
    receive a MSD packet, and initializes the MSD state machine. This
    \function should be called once after the device is enumerated.

  Description:
    This routine initializes the MSD class packet handles, prepares to
    receive a MSD packet, and initializes the MSD state machine. This
    \function should be called once after the device is enumerated.
    
    Typical Usage:
    <code>
    void USBCBInitEP(void)
    {
        USBEnableEndpoint(MSD_DATA_IN_EP,USB_IN_ENABLED|USB_OUT_ENABLED|USB_HANDSHAKE_ENABLED|USB_DISALLOW_SETUP);
        USBMSDInit();
    }
    </code>
  Conditions:
    The device should already be enumerated with a configuration that
    supports MSD before calling this function.
    
  Paramters: None

  Remarks:
    None                                                                                                          
  ****************************************************************************/	
void USBMSDInit(void)
{
    USBMSDInHandle = USBModifyBDT(_EP01_IN, (BYTE*)&msd_csw, MSD_CSW_SIZE, 0x48, UseLiteral);		//Initialize EP1 IN BDT and handle, but don't set UOWN
	USBMSDOutHandle = USBModifyBDT(_EP01_OUT, (BYTE*)&msd_cbw, MSD_OUT_EP_SIZE, 0x88, UseLiteral);	//Prepare to receive first CBW: Set UOWN, clear DTS (always = 0 after set configuration events)
	MSDStatesInit();			//Initialize the media sense and state machine variables.
}

void MSDStatesInit(void)		//Initialize the media sense and state machine variables.
{
    MSD_State = MSD_WAIT;
	MSDCommandState = MSD_COMMAND_WAIT;		
	MSDReadState = MSD_READ10_WAIT;
	MSDWriteState = MSD_WRITE10_WAIT;
	ClearSTALLBlocked = FALSE;
	SkipMSD_SEND_CSWState = FALSE;
	HostNoData = FALSE;
    gblNumBLKS.Val = 0;
    gblBLKLen.Val = 0;

    gblMediaPresent = 0;

    //For each of the possible logical units
    for(gblCBW.bCBWLUN=0;gblCBW.bCBWLUN<(MAX_LUN + 1);gblCBW.bCBWLUN++)
    {
        //see if the media is attached
        if(LUNMediaDetect())
        {
            //initialize the media
            if(LUNMediaInitialize())
            {
                //if the media was present and successfully initialized
                //  then mark and indicator that the media is ready
                gblMediaPresent |= (1<<gblCBW.bCBWLUN);
            }
        }
        ResetSenseData();
    }	
}



	
/******************************************************************************
 	Function:
 		void USBCheckMSDRequest(void)

 	Summary:
 		This routine handles MSD specific request that happen on EP0.  
        This function should be called from the USBCBCheckOtherReq() call back 
        function whenever implementing an MSD device.

 	Description:
 		This routine handles MSD specific request that happen on EP0.  These
        include, but are not limited to, the standard RESET and GET_MAX_LUN 
 		command requests.  This function should be called from the 
        USBCBCheckOtherReq() call back function whenever using an MSD device.	

        Typical Usage:
        <code>
        void USBCBCheckOtherReq(void)
        {
            //Since the stack didn't handle the request I need to check
            //  my class drivers to see if it is for them
            USBCheckMSDRequest();
        }
        </code>

 	PreCondition:
 		None
 		
 	Parameters:
 		None
 	
 	Return Values:
 		None
 		
 	Remarks:
 		None
 
 *****************************************************************************/	
void USBCheckMSDRequest(void)
{
    if(SetupPkt.Recipient != RCPT_INTF) return;
    if(SetupPkt.bIntfID != MSD_INTF_ID) return;

	switch(SetupPkt.bRequest)
    {
	    case MSD_RESET:
	    	if((SetupPkt.wValue != 0x0000) || (SetupPkt.wLength != 0x0000)) //request error if wValue or wLength != 0x0000
	    	{
		    	break;
		    }
		    //else it was a valid request	
			//Important note: According to BOT specification 1.0, don't change DTS bits or BSTALL bits on the bulk IN and OUT endpoints
	    	inPipes[0].info.bits.busy = 1;
	    	outPipes[0].info.bits.busy = 0;

			if(USBHandleBusy(USBMSDInHandle))
			{	//UOWN == 1
				USBMSDInHandle = USBModifyBDT(_EP01_IN, (BYTE*)&msd_csw, MSD_CSW_SIZE, 0x48, SaveBSTALL | TogDTS);	//Clear UOWN, toggle DTS (to incorrect value, but will be correct next time USBTxOnePacket() is called), save the BSTALL state
			}
			else
			{	//UOWN == 0
				USBMSDInHandle = USBModifyBDT(_EP01_IN, (BYTE*)&msd_csw, MSD_CSW_SIZE, 0x48, SaveBSTALL | SaveDTS);	//Clear UOWN, save DTS, save the BSTALL				
			}		
			
			if(USBHandleBusy(USBMSDOutHandle))
			{	//UOWN == 1
				USBMSDOutHandle = USBModifyBDT(_EP01_OUT, (BYTE*)&msd_cbw, MSD_OUT_EP_SIZE, 0xC8, SaveBSTALL | SaveDTS);	//Set UOWN, save DTS (was already correct), save the BSTALL state
			}
			else
			{	//UOWN == 0
				USBMSDOutHandle = USBModifyBDT(_EP01_OUT, (BYTE*)&msd_cbw, MSD_OUT_EP_SIZE, 0xC8, SaveBSTALL | TogDTS);	//Set UOWN, toggle DTS, save the BSTALL state
			}	
		    
			MSDStatesInit();			//Re-initialize the media sense keys and MSD state machine variables.
	    	break;
	    case GET_MAX_LUN:
            //If the host asks for the maximum number of logical units
            //  then send out a packet with that information
	    	if((SetupPkt.wValue != 0x0000) || (SetupPkt.wLength != 0x0001)) //request error if wValue or wLength are incorrect
	    	{
		    	break;
		    }            
	    	CtrlTrfData[0] = MAX_LUN;
            USBEP0SendRAMPtr((BYTE*)&CtrlTrfData[0],1,USB_EP0_INCLUDE_ZERO);
	    	break;
    }	//end switch(SetupPkt.bRequest)
}

/*********************************************************************************
  Function:
        BYTE MSDTasks(void)
    
  Summary:
    This function runs the MSD class state machines and all of its
    sub-systems. This function should be called periodically once the
    device is in the configured state in order to keep the MSD state
    machine going.
  Description:
    This function runs the MSD class state machines and all of its
    sub-systems. This function should be called periodically once the
    device is in the configured state in order to keep the MSD state
    machine going.
    
    Typical Usage:
    <code>
    void main(void)
    {
        USBDeviceInit();
        while(1)
        {
            USBDeviceTasks();
            if((USBGetDeviceState() \< CONFIGURED_STATE) ||
               (USBIsDeviceSuspended() == TRUE))
            {
                //Either the device is not configured or we are suspended
                //  so we don't want to do execute any application code
                continue;   //go back to the top of the while loop
            }
            else
            {
                //Keep the MSD state machine going
                MSDTasks();
    
                //Run application code.
                UserApplication();
            }
        }
    }
    </code>
  Conditions:
    None
  Return Values:
    BYTE -  the current state of the MSD state machine the valid values are
            defined in MSD.h under the MSDTasks state machine declaration section.
            The possible values are the following\:
            * MSD_WAIT
            * MSD_DATA_IN
            * MSD_DATA_OUT
            * MSD_SEND_CSW
  Remarks:
    None                                                                          
  *********************************************************************************/	
BYTE MSDTasks(void)
{
    BYTE i;
    
    switch(MSD_State)
    {
        case MSD_WAIT:		//Waiting for a CBW to arrive
        {
            //If the MSD state machine is waiting for something to happen
            if(!USBHandleBusy(USBMSDOutHandle))
            {
        		//If we received an OUT packet from the host
                //  then copy the data from the buffer to a global
                //  buffer so that we can keep the information but
                //  reuse the buffer
        		gblCBW.dCBWSignature=msd_cbw.dCBWSignature;					
        		gblCBW.dCBWTag=msd_cbw.dCBWTag;
        		gblCBW.dCBWDataTransferLength=msd_cbw.dCBWDataTransferLength;
            	gblCBW.bCBWFlags=msd_cbw.bCBWFlags;
            	gblCBW.bCBWLUN=msd_cbw.bCBWLUN;
        	    gblCBW.bCBWCBLength=msd_cbw.bCBWCBLength;		// 3 MSB are zero

            	for (i=0;i<0x10;i++)	//Copy the CB from endpoint buffer, to global variable array.
            	{						//0x10 is the maximum legal CB length for this type of device. 
            		gblCBW.CBWCB[i]=msd_cbw.CBWCB[i];
                }
            		
                gblCBWLength=USBHandleGetLength(USBMSDOutHandle);

        	    //Is this CBW "valid"?
        		if ((gblCBWLength==MSD_CBW_SIZE)&&(gblCBW.dCBWSignature==0x43425355)) 
            	{	//CBW must have been valid if executes to here (definition of "valid" is in BOT specification section 6.2.1)
                    
                    //Now check: Is this CBW meaningful?	("meaningful" defined in BOT specs. section 6.2.2)
       				if((gblCBW.bCBWLUN<=(BYTE)MAX_LUN)
               		&&(gblCBW.bCBWCBLength<=0x10)
               		&&(gblCBW.bCBWCBLength>=0x01)
               		&&(gblCBW.bCBWFlags==0x00||gblCBW.bCBWFlags==0x80)) 		//Should check reserved bits are all clear as well
            		{
                		//Prepare the CSW to be sent
                    	msd_csw.dCSWTag=gblCBW.dCBWTag;
                    	msd_csw.dCSWSignature=0x53425355;
                    	
                    	if(gblCBW.dCBWDataTransferLength == 0)		//Figure this out for quicker error checking later
                    	{
	                    	HostNoData = TRUE;
	                    }
	                    else
	                    {
		                    HostNoData = FALSE;
		                } 	
                    	
        				/* If direction is device to host*/
        				if (gblCBW.bCBWFlags==0x80)
        				{
        					MSD_State=MSD_DATA_IN;
        				}
        				else if (gblCBW.bCBWFlags==0x00) 
            			{
        					/* If direction is host to device*/
        					/* prepare to read data in msd_buffer */
            			    MSD_State=MSD_DATA_OUT;
        				}        								
        			}
        			else	//something is wrong, the CBW is not "meaningful"
        			{
	        			//Section 6.4 of the BOT specifications rev. 1.0 indicate that the device response to a
	        			//not "meaningful" CBW is unspecified.  However, to avoid potential data corruption, and to
	        			//increase the probability of the host performing an MSD reset, and eventual error case 
	        			//recovery, lets stall the bulk IN and OUT endpoints
          				USBStallEndpoint(MSD_DATA_IN_EP,1);
          				USBStallEndpoint(MSD_DATA_OUT_EP,0);
	        		}	
        		}
        		else	//something is wrong, the CBW is not "valid"
        		{
	        		//Section 6.4.1 of the BOT specifications rev. 1.0 says the device should STALL bulk IN and OUT
	        		//endpoints, and should stay in this state until a "Reset Recovery" (MSD Reset command on EP0)
          			USBStallEndpoint(MSD_DATA_IN_EP,1);
          			USBStallEndpoint(MSD_DATA_OUT_EP,0);       		
        			ClearSTALLBlocked = TRUE;  	//Prevent the STALL condition from being cleared, even by a SET_FEATURE clear endpoint stall request
        										//This condition is only cleared by an MSD Reset (or a SET_CONFIGURATION, which is a harder reset)
	        	}	
            }
            break;
        }
        case MSD_DATA_IN:
            if(MSDProcessCommand() == MSD_COMMAND_WAIT)
            {
                // Done processing the command, send the status
                MSD_State = MSD_SEND_CSW;
            }
            break;
        case MSD_DATA_OUT:
            if(MSDProcessCommand() == MSD_COMMAND_WAIT)
            {
    			/* Finished receiving the data, send the CSW */
                MSD_State = MSD_SEND_CSW;
            }
            break;
        case MSD_SEND_CSW:
			if(SkipMSD_SEND_CSWState == TRUE)		//Special handling needed when error case (10): Ho <> Di occurs (see section 6.7 of BOT specifications revision 1.0)
			{
				SkipMSD_SEND_CSWState = FALSE;
				MSD_State = MSD_WAIT;
				break;
			}	
			
			if(USBHandleBusy(USBMSDInHandle))
            {
                //The TX buffer is not ready to send the status yet.
                break;
            }
            
            //Send the CSW and prepare the OUT endpoint for receiving the next CBW
            if(!USBHandleBusy(USBMSDOutHandle))
            {
	            USBMSDInHandle = USBTxOnePacket(MSD_DATA_IN_EP,(BYTE*)&msd_csw,MSD_CSW_SIZE);		//Send the CSW
                USBMSDOutHandle = USBRxOnePacket(MSD_DATA_OUT_EP,(BYTE*)&msd_cbw,MSD_OUT_EP_SIZE);	//Prepare to receive the next CBW
	           	MSD_State=MSD_WAIT;
            }
            break;
    }
    
    return MSD_State;
}

/******************************************************************************
 	Function:
 		void MSDProcessCommandMediaPresent(void)
 		
 	Description:
 		This funtion processes a command received through the MSD
 		class driver
 		
 	PreCondition:
 		None
 		
 	Paramters:
 		None
 	
 	Return Values:
 		BYTE - the current state of the MSDProcessCommand state
 		machine.  The valid values are defined in MSD.h under the 
 		MSDProcessCommand state machine declaration section
 		
 	Remarks:
 		None
 
 *****************************************************************************/	
void MSDProcessCommandMediaPresent(void)
{
    BYTE i; 


    switch(MSDCommandState)
    {
        case MSD_COMMAND_WAIT:
            //copy the received command to the command state machine
            MSDCommandState = gblCBW.CBWCB[0];
            break;
    	case MSD_INQUIRY:
    	{
	    	//Check for possible errors.  Inquiry is supposed to send 36 byte packet to host + CSW
        	if(MSD_State != MSD_DATA_IN)
        	{
	        	if(HostNoData)
	        	{	
		        	MSDErrorHandler(CASE_3);
		        	return;
		        }	
	        	if(gblCBW.CBWCB[4] == 0)
	        		MSDErrorHandler(CASE_9);
	        	else
	        		MSDErrorHandler(CASE_10);
	        	return;
	        }
	        if(HostNoData)
	        {
	        	MSDErrorHandler(CASE_2);
	        	return;
	        }
	        if(gblCBW.CBWCB[4] == 0)
	        {
	        	MSDErrorHandler(CASE_4);
	        	return;
		    }
		    if(gblCBW.dCBWDataTransferLength < (DWORD)gblCBW.CBWCB[4])
	        {
	        	MSDErrorHandler(CASE_7);
	        	return;
		    }
		    else if(gblCBW.dCBWDataTransferLength > (DWORD)gblCBW.CBWCB[4])
	        {
	        	MSDErrorHandler(CASE_5);
	        	return;
		    }
		    
		    if((gblCBW.dCBWDataTransferLength != 0x24) || (gblCBW.CBWCB[4] != 0x24))	//Inquiry requests should always have 0x24 byte response
		    {
			   MSDErrorHandler(CASE_4);		//STALL IN endpoint, and return error.
			   return; 
			} 
		    
            //copy the inquiry results from the defined ROM buffer 
            //  into the USB buffer so that it can be transmitted
        	memcpypgm2ram(
        	    (void *)&msd_buffer[0],
        	    (ROM void*)&inq_resp,
        	    sizeof(InquiryResponse)
        	    );
        	msd_csw.dCSWDataResidue=sizeof(InquiryResponse);
        	msd_csw.bCSWStatus=0x00;			// success
        	MSDCommandState = MSD_COMMAND_RESPONSE;
            break;
        }
        case MSD_READ_CAPACITY:
        {
            //If the host asked for the capacity of the device
            DWORD_VAL sectorSize;
            DWORD_VAL capacity;

        	msd_csw.bCSWStatus=0x00;			  // success
            
            //get the information from the physical media
            capacity.Val = LUNReadCapacity();
            sectorSize.Val = LUNReadSectorSize();
            
            //copy the data to the buffer
        	msd_buffer[0]=capacity.v[3];
        	msd_buffer[1]=capacity.v[2];
        	msd_buffer[2]=capacity.v[1];
        	msd_buffer[3]=capacity.v[0];
        	
        	msd_buffer[4]=sectorSize.v[3];
        	msd_buffer[5]=sectorSize.v[2];
        	msd_buffer[6]=sectorSize.v[1];
        	msd_buffer[7]=sectorSize.v[0];
        
        	msd_csw.dCSWDataResidue=0x08;		  // size of response
        	MSDCommandState = MSD_COMMAND_RESPONSE;
            break;
        }
		case MSD_READ_10:
        	if(MSDReadHandler() == MSD_READ10_WAIT)
        	{
			    MSDCommandState = MSD_COMMAND_WAIT;
            }
            break;
    	case MSD_WRITE_10:
        	if(MSDWriteHandler() == MSD_WRITE10_WAIT)
        	{
			    MSDCommandState = MSD_COMMAND_WAIT;
            }
		    break;
        case MSD_REQUEST_SENSE:    
	    	//Check for possible errors. 
        	if(MSD_State != MSD_DATA_IN)
        	{
	        	if(HostNoData)
	        	{	
		        	MSDErrorHandler(CASE_3);
		        	return;
		        }	
	        	if(gblCBW.CBWCB[4] == 0)
	        		MSDErrorHandler(CASE_9);
	        	else
	        		MSDErrorHandler(CASE_10);
	        	return;
	        }
	        if(HostNoData)
	        {
	        	MSDErrorHandler(CASE_2);
	        	return;
	        }
	        if(gblCBW.CBWCB[4] == 0)
	        {
	        	MSDErrorHandler(CASE_4);
	        	return;
		    }
		    if(gblCBW.dCBWDataTransferLength < (DWORD)gblCBW.CBWCB[4])
	        {
	        	MSDErrorHandler(CASE_7);
	        	return;
		    }
		    else if(gblCBW.dCBWDataTransferLength > (DWORD)gblCBW.CBWCB[4])
	        {
	        	MSDErrorHandler(CASE_5);
	        	return;
		    }
		    
          	for(i=0;i<sizeof(RequestSenseResponse);i++)		//Copy the sense data into the buffer.  
			{
          		msd_buffer[i]=gblSenseData[LUN_INDEX]._byte[i];
            }

			//Note: may not send all of it if the request was smaller than the complete sense data.          	
			if(gblCBW.CBWCB[4] <= (BYTE)sizeof(RequestSenseResponse))
			{
				msd_csw.dCSWDataResidue = gblCBW.CBWCB[4];	//Not really, the actual residue is 0x00, but this is used by MSD_COMMAND_RESPONSE
															//to determine number of bytes to send.
			}	
			else //(gblCBW.CBWCB[4] > (BYTE)sizeof(RequestSenseResponse))
			{
            	if(USBHandleBusy(USBMSDInHandle))
            	{
	            	break;
	            }	
            		
            	gblCBW.dCBWDataTransferLength = gblCBW.dCBWDataTransferLength - (BYTE)sizeof(RequestSenseResponse);
            	msd_csw.bCSWStatus=0x1;		//Fail
	       		USBMSDInHandle = USBTxOnePacket(MSD_DATA_IN_EP,(BYTE*)&msd_csw, (BYTE)sizeof(RequestSenseResponse));	//Send the response, this will be a short packet.
            	MSDCommandState = MSD_SENT_SHORT_PACKET;		//Now need to STALL further IN packets, to advance host state machine to CSW phase.
            	return;
   			}         	

          	msd_csw.bCSWStatus=0x0;					// success
          	MSDCommandState = MSD_COMMAND_RESPONSE;
            break;
	    case MSD_MODE_SENSE:
        	msd_buffer[0]=0x02;
        	msd_buffer[1]=0x00;
        	msd_buffer[2]=0x00;
        	msd_buffer[3]=0x00;
        	
        	msd_csw.bCSWStatus=0x0;
        	msd_csw.dCSWDataResidue=0x04;
        	MSDCommandState = MSD_COMMAND_RESPONSE;
    	    break;
		case MSD_PREVENT_ALLOW_MEDIUM_REMOVAL:
            if(LUNMediaDetect())
            {
        		msd_csw.bCSWStatus=0x00;
        		msd_csw.dCSWDataResidue=0x00;
        	}
            else
            {
        		gblSenseData[LUN_INDEX].SenseKey=S_NOT_READY;
        		gblSenseData[LUN_INDEX].ASC=ASC_MEDIUM_NOT_PRESENT;
        		gblSenseData[LUN_INDEX].ASCQ=ASCQ_MEDIUM_NOT_PRESENT;
        		msd_csw.bCSWStatus=0x01;
        	}
			MSDCommandState = MSD_COMMAND_WAIT;
            break;
		case MSD_TEST_UNIT_READY:
            //Check for error cases.  Need to handle the 13 error cases as mentioned in the BOT revision 1.0 specifications section 6.7.
            if(!HostNoData)
            {
	            if(MSD_State == MSD_DATA_IN)
	            	MSDErrorHandler(CASE_4);
	            else //must be MSD_State == MSD_DATA_OUT
	            	MSDErrorHandler(CASE_9);
	            return;
	        } 
	        
	        if((gblSenseData[LUN_INDEX].SenseKey==S_UNIT_ATTENTION) && (msd_csw.bCSWStatus==1))
            {
                MSDCommandState = MSD_COMMAND_WAIT;
            }
            else
            {
            	ResetSenseData();
            	msd_csw.dCSWDataResidue=0x00;			//Added5Jan09 Prepare CSW packet
        		msd_csw.bCSWStatus=0x00;				//Added5Jan09 Success
    			MSDCommandState = MSD_COMMAND_WAIT;		//Added5Jan09
            }
            break;
		case MSD_VERIFY:
            //Fall through to STOP_START
		case MSD_STOP_START:
        	msd_csw.bCSWStatus=0x0;
        	msd_csw.dCSWDataResidue=0x00;
			MSDCommandState = MSD_COMMAND_WAIT;
            break;
        case MSD_COMMAND_RESPONSE:
			if(USBHandleBusy(USBMSDInHandle))
          	{
               	break;
           	}
    
            USBMSDInHandle = USBTxOnePacket(MSD_DATA_IN_EP,(BYTE*)&msd_buffer[0],msd_csw.dCSWDataResidue);
		    MSDCommandState = MSD_COMMAND_WAIT;
      		msd_csw.dCSWDataResidue=0;
            break;
        case MSD_SENT_SHORT_PACKET:
           	MSDErrorHandler(CASE_4);	//STALL bulk IN after sending the short packet above
			return;
        case MSD_COMMAND_ERROR:
		default:	//Unrecognized command.
        	ResetSenseData();
			gblSenseData[LUN_INDEX].SenseKey=S_ILLEGAL_REQUEST;
			gblSenseData[LUN_INDEX].ASC=ASC_INVALID_COMMAND_OPCODE;
			gblSenseData[LUN_INDEX].ASCQ=ASCQ_INVALID_COMMAND_OPCODE;
			msd_csw.bCSWStatus=0x01;
			msd_csw.dCSWDataResidue=0x00;

	    	//Check for possible errors.
        	if(MSD_State != MSD_DATA_IN)
        	{
	        	if(HostNoData)
	        	{	
       			    MSDCommandState = MSD_COMMAND_WAIT;	//Just send bCSWStatus=0x01 with no residue.  Host will then probably request sense data.
		        	return;
		        }
		        else
		        {
			        MSDErrorHandler(CASE_9);	//STALL bulk OUT, to prevent host sending us data associated with the command
			        return;
			    } 	
	        }
	        else	//MSD_State must be MSD_DATA_IN
	        {
		        if(HostNoData)
		        {
       			    MSDCommandState = MSD_COMMAND_WAIT;	//Just send bCSWStatus=0x01 with no residue.  Host will then know to request sense data.
		        	return;
		        }
		        else
		        {
			        MSDErrorHandler(CASE_4);	//STALL bulk IN to prevent host from receiving bogus data in "fulfillment" of the
			        return;					//unknown command.  Host will probably request sense data after it sees 0x01 in bCSWStatus of CSW.
			    } 
		    } 

			//Impossible to get here.  Above ifs and elses cover all possibilities.

 		    break;
	} // end switch	
}



/******************************************************************************
 	Function:
 		void MSDProcessCommandMediaAbsent(void)
 		
 	Description:
 		This funtion processes a command received through the MSD
 		class driver
 		
 	PreCondition:
 		None
 		
 	Parameters:
 		None
 	
 	Return Values:
 		BYTE - the current state of the MSDProcessCommand state
 		machine.  The valid values are defined in MSD.h under the 
 		MSDProcessCommand state machine declaration section
 		
 	Remarks:
 		None
 
  *****************************************************************************/	
void MSDProcessCommandMediaAbsent(void)
{
    BYTE i;

    switch(MSDCommandState)
    {
        case MSD_REQUEST_SENSE:
        {
            ResetSenseData();
            gblSenseData[LUN_INDEX].SenseKey=S_NOT_READY;
    		gblSenseData[LUN_INDEX].ASC=ASC_MEDIUM_NOT_PRESENT;
    		gblSenseData[LUN_INDEX].ASCQ=ASCQ_MEDIUM_NOT_PRESENT;

          	for(i=0;i<sizeof(RequestSenseResponse);i++)
          	{
          		msd_buffer[i]=gblSenseData[LUN_INDEX]._byte[i];
            }
          	
            msd_csw.dCSWDataResidue=sizeof(RequestSenseResponse);
          	msd_csw.bCSWStatus=0x0;					// success
          	MSDCommandState = MSD_COMMAND_RESPONSE;
            break;
        } 
        case MSD_PREVENT_ALLOW_MEDIUM_REMOVAL:
        case MSD_TEST_UNIT_READY:
        {
    		msd_csw.bCSWStatus=0x01;
            MSDCommandState = MSD_COMMAND_WAIT;
            break;
        }
        case MSD_INQUIRY:
        {
        	memcpypgm2ram(
        	    (void *)&msd_buffer[0],
        	    (ROM void*)&inq_resp,
        	    sizeof(InquiryResponse)
        	    );
        	msd_csw.dCSWDataResidue=sizeof(InquiryResponse);
        	msd_csw.bCSWStatus=0x00;			// success
        	MSDCommandState = MSD_COMMAND_RESPONSE;
            break;
        }
        case MSD_COMMAND_WAIT:
        {
            MSDCommandState = gblCBW.CBWCB[0];
            break;
        }
        case MSD_COMMAND_RESPONSE:
            if(USBMSDInHandle != 0)
			{
				if(USBHandleBusy(USBMSDInHandle))
               	{
                   	break;
               	}
   			}
   			  
            USBMSDInHandle = USBTxOnePacket(MSD_DATA_IN_EP,(BYTE*)&msd_buffer[0],msd_csw.dCSWDataResidue);
		    MSDCommandState = MSD_COMMAND_WAIT;

      		msd_csw.dCSWDataResidue=0;
            break;
        default:
        {
            //Stall MSD endpoint IN
            USBStallEndpoint(MSD_DATA_IN_EP,1);
    		msd_csw.bCSWStatus=0x01;
            MSDCommandState = MSD_COMMAND_WAIT;
            break;
        }
    }
}

/******************************************************************************
 	Function:
 		BYTE MSDProcessCommand(void)
 		
 	Description:
 		This funtion processes a command received through the MSD
 		class driver
 		
 	PreCondition:
 		None
 		
 	Paramters:
 		None
 		
 	Return Values:
 		BYTE - the current state of the MSDProcessCommand state
 		machine.  The valid values are defined in MSD.h under the
 		MSDProcessCommand state machine declaration section
 		
 	Remarks:
 		None
 
 *****************************************************************************/	
BYTE MSDProcessCommand(void)
{   
  	if(LUNMediaDetect() == FALSE)
    {
        gblMediaPresent &= ~(1<<gblCBW.bCBWLUN);

        MSDProcessCommandMediaAbsent();
   	}
    else
    {
        if((gblMediaPresent & (1<<gblCBW.bCBWLUN)) == 0)
        {
            if(LUNMediaInitialize())
            {
                gblMediaPresent |= (1<<gblCBW.bCBWLUN);

        		gblSenseData[LUN_INDEX].SenseKey=S_UNIT_ATTENTION;
        		gblSenseData[LUN_INDEX].ASC=0x28;
        		gblSenseData[LUN_INDEX].ASCQ=0x00;
                msd_csw.bCSWStatus=0x01;

                MSDProcessCommandMediaPresent();
            }
            else
            {
                MSDProcessCommandMediaAbsent();
            }
        }
        else
        {
            MSDProcessCommandMediaPresent();
        }
    }

    return MSDCommandState;
}

/******************************************************************************
 	Function:
 		BYTE MSDReadHandler(void)
 		
 	Description:
 		This funtion processes a read command received through 
 		the MSD class driver
 		
 	PreCondition:
 		None
 		
 	Parameters:
 		None
 		
 	Return Values:
 		BYTE - the current state of the MSDReadHandler state
 		machine.  The valid values are defined in MSD.h under the 
 		MSDReadHandler state machine declaration section
 		
 	Remarks:
 		None
 
  *****************************************************************************/

BYTE MSDReadHandler(void)
{
    switch(MSDReadState)
    {
        case MSD_READ10_WAIT:
        	LBA.v[3]=gblCBW.CBWCB[2];	//Extract the logical block address (LBA) information from the SCSI command block portion of the command block wrapper
        	LBA.v[2]=gblCBW.CBWCB[3];
        	LBA.v[1]=gblCBW.CBWCB[4];
        	LBA.v[0]=gblCBW.CBWCB[5];
        	
        	TransferLength.v[1]=gblCBW.CBWCB[7];		//Extract the number of blocks to transfer from the command block portion of the CBW
        	TransferLength.v[0]=gblCBW.CBWCB[8];

            //Check for error cases.  Need to handle the 13 error cases as mentioned in the BOT revision 1.0 specifications section 6.7.
        	//Error checking: check for case (10): Ho <> Di (see section 6.7 of BOT specifications revision 1.0)
        	if(MSD_State != MSD_DATA_IN)
	        {
		        MSDErrorHandler(CASE_10);
		        return MSD_READ10_WAIT;
		    } 

			msd_csw.bCSWStatus=0x00;			//Assume success, until a failure occurs.  If that happens, change this value then.
        	msd_csw.dCSWDataResidue=0x0;
        	
        	//Error checking: check for case (2): Hn < Di (see section 6.7 of BOT specifications revision 1.0)
        	if(HostNoData && (TransferLength.Val != 0))	
        	{
	        	MSDErrorHandler(CASE_2);
	        	return MSD_READ10_WAIT;
	        }	

        	//Error checking: check for case (4): Hi > Dn (see section 6.7 of BOT specifications revision 1.0)
        	if((!HostNoData) && (TransferLength.Val == 0))	
        	{
	        	MSDErrorHandler(CASE_4);
	        	return MSD_READ10_WAIT;
	        }	
        	
        	//Error checking: check for case (7): Hi < Di (see section 6.7 of BOT specifications revision 1.0)
        	if((DWORD)gblCBW.dCBWDataTransferLength < ((DWORD)((DWORD)TransferLength.Val * (DWORD)BLOCKLEN_512)))	
        	{
        		MSDErrorHandler(CASE_7);
        		return MSD_READ10_WAIT;
	        }	
        	
            MSDReadState = MSD_READ10_BLOCK;
            //Fall through to MSD_READ_BLOCK
        case MSD_READ10_BLOCK:
            if(TransferLength.Val == 0)		//Check if finished sending the requested data
            {
        		//Error checking: check for case (5): Hi > Di (see section 6.7 of BOT specifications revision 1.0)
	            if(gblCBW.dCBWDataTransferLength != 0)	//Happens when error case (5): Hi > Di occurs
	            {
					MSDErrorHandler(CASE_5);
					return MSD_READ10_WAIT;
		        } 
		        
                MSDReadState = MSD_READ10_WAIT;
                break;
            }
            
            MSDReadState = MSD_READ10_SECTOR;
            TransferLength.Val--;			// we will have read 1 LBA when state MSD_READ10_SECTOR completes
            //Fall through to MSD_READ10_SECTOR
        case MSD_READ10_SECTOR:
            if(USBHandleBusy(USBMSDInHandle))
            { 	//Can't proceed yet if the endpoint isn't finished with the previous transmission.
	            //In this case, need to stay in this state and wait for the endpoint to become free.
                break;
            }

    		if(LUNSectorRead(LBA.Val, (BYTE*)&msd_buffer[0]) != TRUE)		//This will perform the actual read operation, and put the data in the msd_buffer[]
    		{
				msd_csw.bCSWStatus=0x01;			// Error 0x01 Refer page#18
                                                    // of BOT specifications
				/* Don't read any more data*/
				msd_csw.dCSWDataResidue=0x0;
              
                MSD_State = MSD_DATA_IN;
        		break;
            }

            LBA.Val++;
            
			msd_csw.dCSWDataResidue=BLOCKLEN_512;//in order to send the
                                                 //512 bytes of data read
                                                 
            ptrNextData=(BYTE *)&msd_buffer[0];
            
            MSDReadState = MSD_READ10_TX_SECTOR;
    
            //Fall through to MSD_READ10_TX_SECTOR
        case MSD_READ10_TX_SECTOR:					//A sector is normally 512 bytes, but the MSD endpoint is normally 64 bytes large.  Need to transmit over the course of several packets, in the "MSD_READ10_TX_PACKET" state
            if(msd_csw.dCSWDataResidue == 0)		
            {
                MSDReadState = MSD_READ10_BLOCK;
                break;
            }
            
            MSDReadState = MSD_READ10_TX_PACKET;
            //Fall through to MSD_READ10_TX_PACKET
        case MSD_READ10_TX_PACKET:
        	if ((msd_csw.bCSWStatus==0x00)&&(msd_csw.dCSWDataResidue>=MSD_IN_EP_SIZE)) 
            {
        		/* Write next chunk of data to EP Buffer and send */
				if(USBHandleBusy(USBMSDInHandle))
               	{
                   	break;
               	}
                
                USBMSDInHandle = USBTxOnePacket(MSD_DATA_IN_EP,ptrNextData,MSD_IN_EP_SIZE);
                
  			    MSDReadState = MSD_READ10_TX_SECTOR;

        		gblCBW.dCBWDataTransferLength-=	MSD_IN_EP_SIZE;
        		msd_csw.dCSWDataResidue-=MSD_IN_EP_SIZE;
        		ptrNextData+=MSD_IN_EP_SIZE;
        	}
            break;
    }
    
    return MSDReadState;
}


/******************************************************************************
 	Function:
 		BYTE MSDWriteHandler(void)
 		
 	Description:
 		This funtion processes a write command received through 
 		the MSD class driver
 		
 	PreCondition:
 		None
 		
 	Parameters:
 		None
 		
 	Return Values:
 		BYTE - the current state of the MSDWriteHandler state
 		machine.  The valid values are defined in MSD.h under the 
 		MSDWriteHandler state machine declaration section
 		
 	Remarks:
 		None
 
 *****************************************************************************/
BYTE MSDWriteHandler(void)
{
    switch(MSDWriteState)
    {
        case MSD_WRITE10_WAIT:
         	/* Read the LBA, TransferLength fields from Command Block
               NOTE: CB is Big-Endian */
        
        	LBA.v[3]=gblCBW.CBWCB[2];
        	LBA.v[2]=gblCBW.CBWCB[3];
        	LBA.v[1]=gblCBW.CBWCB[4];
        	LBA.v[0]=gblCBW.CBWCB[5];
        	TransferLength.v[1]=gblCBW.CBWCB[7];
        	TransferLength.v[0]=gblCBW.CBWCB[8];

        	//Error checking: check for case (8): Hi <> Do (see section 6.7 of BOT specifications revision 1.0)
        	if(MSD_State != MSD_DATA_OUT)
	        {
		        MSDErrorHandler(CASE_8);
		        return MSD_WRITE10_WAIT;
		    } 

        	//Error checking: check for case (3): Hn < Do (see section 6.7 of BOT specifications revision 1.0)
        	if(HostNoData && (TransferLength.Val != 0))	//Host expects no data, even though this was a legitimate WRITE10 command
        	{
			    MSDErrorHandler(CASE_3);
			    return MSD_WRITE10_WAIT;	        	
	        }

        	//Error checking: check for case (13): Ho < Do (see section 6.7 of BOT specifications revision 1.0)
        	if((DWORD)gblCBW.dCBWDataTransferLength < ((DWORD)((DWORD)TransferLength.Val * (DWORD)BLOCKLEN_512)))	
		    {
			    MSDErrorHandler(CASE_13);
			    return MSD_WRITE10_WAIT;
		    } 
        
        	msd_csw.bCSWStatus=0x0;	
        	
        	MSD_State = MSD_WRITE10_BLOCK;
        	//Fall through to MSD_WRITE10_BLOCK
        case MSD_WRITE10_BLOCK:
            if(TransferLength.Val == 0)
            {
        		//Error checking: check for cases (9) and (11): Ho > Dn and Ho > Do (see section 6.7 of BOT specifications revision 1.0)
	            if(gblCBW.dCBWDataTransferLength != 0)	//Happens when error case (11): Ho > Do occurs
	            {
		            MSDErrorHandler(CASE_9); //And CASE_9 == CASE_11
		            return MSD_WRITE10_WAIT;
		        } 

                MSDWriteState = MSD_WRITE10_WAIT;
                break;
            }
            
            ptrNextData=(BYTE *)&msd_buffer[0];
        	msd_csw.dCSWDataResidue=BLOCKLEN_512;

            MSDWriteState = MSD_WRITE10_RX_SECTOR;        	
            //Fall through to MSD_WRITE10_RX_SECTOR
        case MSD_WRITE10_RX_SECTOR:
        {
      		/* Read 512B into msd_buffer*/
      		if(msd_csw.dCSWDataResidue>0) 
      		{
                if(USBHandleBusy(USBMSDOutHandle))
                {
                    break;
                }

                USBMSDOutHandle = USBRxOnePacket(MSD_DATA_OUT_EP,ptrNextData,MSD_OUT_EP_SIZE);
                MSDWriteState = MSD_WRITE10_RX_PACKET;
                //Fall through to MSD_WRITE10_RX_PACKET
      	    }
      	    else
      	    {
          		if(LUNWriteProtectState()) 
                {
              	    gblSenseData[LUN_INDEX].SenseKey=S_NOT_READY;
              	    gblSenseData[LUN_INDEX].ASC=ASC_WRITE_PROTECTED;
              	    gblSenseData[LUN_INDEX].ASCQ=ASCQ_WRITE_PROTECTED;
              	    msd_csw.bCSWStatus=0x01;
              	    //TODO: (DF) - what state should I return to?
              	}
              	else
              	{
      			    MSDWriteState = MSD_WRITE10_SECTOR;     
      			}
      			break;
          	}
        }
        //Fall through to MSD_WRITE10_RX_PACKET
        case MSD_WRITE10_RX_PACKET:
            if(USBHandleBusy(USBMSDOutHandle))
            {
                break;
            }
            
        	gblCBW.dCBWDataTransferLength-=USBHandleGetLength(USBMSDOutHandle);		// 64B read
        	msd_csw.dCSWDataResidue-=USBHandleGetLength(USBMSDOutHandle);
            ptrNextData += MSD_OUT_EP_SIZE;
            
            MSDWriteState = MSD_WRITE10_RX_SECTOR;
            break;
        case MSD_WRITE10_SECTOR:
        {
	        //Check for illegal write address. 
	        if(LBA.Val > (MDD_INTERNAL_FLASH_TOTAL_DISK_SIZE))
	        {
		        //Trying to write past the end of the "disk"; Need to prevent this
		        //to avoid accidentally erasing important non-disk data.
				//TODO: Should set sense keys here. So host will know what happened.
				MSDErrorHandler(CASE_9);
				return MSD_WRITE10_WAIT;
		    } 
	        
      		if(LUNSectorWrite(LBA.Val, (BYTE*)&msd_buffer[0], FALSE) != TRUE)
      		{
          		break;
      		}
      
    //		if (status) {
    //			msd_csw.bCSWStatus=0x01;
    //			/* add some sense keys here*/
    //		}
      
      		LBA.Val++;				// One LBA is written. Write the next LBA
      		TransferLength.Val--;
      
            MSDWriteState = MSD_WRITE10_BLOCK;
            break;
        } 
    }
    
    return MSDWriteState;
}

/******************************************************************************
 	Function:
 		void ResetSenseData(void)
 		
 	Description:
 		This routine resets the Sense Data, initializing the
 		structure RequestSenseResponse gblSenseData.
 		
 	PreCondition:
 		None 
 		
 	Parameters:
 		None
 		
 	Return Values:
 		None
 		
 	Remarks:
 		None
 			
  *****************************************************************************/
void ResetSenseData(void) 
{
	gblSenseData[LUN_INDEX].ResponseCode=S_CURRENT;
	gblSenseData[LUN_INDEX].VALID=0;			// no data in the information field
	gblSenseData[LUN_INDEX].Obsolete=0x0;
	gblSenseData[LUN_INDEX].SenseKey=S_NO_SENSE;
	//gblSenseData.Resv;
	gblSenseData[LUN_INDEX].ILI=0;
	gblSenseData[LUN_INDEX].EOM=0;
	gblSenseData[LUN_INDEX].FILEMARK=0;
	gblSenseData[LUN_INDEX].InformationB0=0x00;
	gblSenseData[LUN_INDEX].InformationB1=0x00;
	gblSenseData[LUN_INDEX].InformationB2=0x00;
	gblSenseData[LUN_INDEX].InformationB3=0x00;
	gblSenseData[LUN_INDEX].AddSenseLen=0x0a;	// n-7 (n=17 (0..17))
	gblSenseData[LUN_INDEX].CmdSpecificInfo.Val=0x0;
	gblSenseData[LUN_INDEX].ASC=0x0;
	gblSenseData[LUN_INDEX].ASCQ=0x0;
	gblSenseData[LUN_INDEX].FRUC=0x0;
	gblSenseData[LUN_INDEX].SenseKeySpecific[0]=0x0;
	gblSenseData[LUN_INDEX].SenseKeySpecific[1]=0x0;
	gblSenseData[LUN_INDEX].SenseKeySpecific[2]=0x0;
}



void MSDErrorHandler(BYTE ErrorCase)
{
	//Both MSD bulk IN and OUT endpoints should not be busy when these error cases are detected
	//If for some reason this isn't true, then we should preserve the state machines states for now.
    if((USBHandleBusy(USBMSDInHandle)) || (USBHandleBusy(USBMSDOutHandle)))
    {
    	return;	
    }

	//Reset main state machines
	MSDCommandState = MSD_COMMAND_WAIT;
	MSDReadState = MSD_READ10_WAIT;
	MSDWriteState = MSD_WRITE10_WAIT;
	MSD_State = MSD_SEND_CSW;		
	
	switch(ErrorCase)
	{
		case CASE_2://Alse CASE_3
			msd_csw.bCSWStatus=0x02;		//Indicate phase error to host.
        	break;	
		case CASE_4://Also CASE_5
       		USBStallEndpoint(MSD_DATA_IN_EP,1);	//STALL the bulk IN MSD endpoint
  	    	msd_csw.bCSWStatus=0x01;		//Indicate error to host. (won't get sent until after host does a CLEAR_FEATURE to end the STALL)
  	    	msd_csw.dCSWDataResidue = gblCBW.dCBWDataTransferLength;
			break;
		case CASE_7://Also CASE_8
       		msd_csw.bCSWStatus = 0x02;		//Indicate phase error to host.
       		msd_csw.dCSWDataResidue = 0x00;	//Value probably not important
       		USBStallEndpoint(MSD_DATA_IN_EP,1);	//STALL the bulk IN MSD endpoint
       		break;		
		case CASE_9://Also CASE_11
	        msd_csw.bCSWStatus = 0x01;				//Indicate error to host.
      		msd_csw.dCSWDataResidue = gblCBW.dCBWDataTransferLength;	//Indicate the unconsumed data
			//Need to toggle the DTS bit of the MSD_DATA_OUT_EP, and set the STALL bit
			USBMSDOutHandle = USBModifyBDT(MSD_DATA_OUT_EP | _EP_OUT, (BYTE*)&msd_cbw, MSD_OUT_EP_SIZE, 0x8C, TogDTS);	//STALL the bulk OUT MSD endpoint
       		USBMSDInHandle = USBTxOnePacket(MSD_DATA_IN_EP,(BYTE*)&msd_csw,MSD_CSW_SIZE);		//Send the CSW
			//Need to skip the MSD_State -> MSD_SEND_CSW step.  We already prepared the CSW in this local code.
			SkipMSD_SEND_CSWState = TRUE;
			break;
		case CASE_10://Also CASE_13
	        msd_csw.bCSWStatus = 0x02;				//Indicate phase error to host.
       		msd_csw.dCSWDataResidue = 0x00;			//Value probably not important
			//Need to toggle the DTS bit of the MSD_DATA_OUT_EP, and set the STALL bit
			USBMSDOutHandle = USBModifyBDT(MSD_DATA_OUT_EP, (BYTE*)&msd_cbw, MSD_OUT_EP_SIZE, 0x8C, TogDTS);	//STALL the bulk OUT MSD endpoint
       		USBMSDInHandle = USBTxOnePacket(MSD_DATA_IN_EP,(BYTE*)&msd_csw,MSD_CSW_SIZE);		//Send the CSW
			//Need to skip the MSD_State -> MSD_SEND_CSW step.  We already prepared the CSW in this local code.
			SkipMSD_SEND_CSWState = TRUE;
			break;
		default:	//Shouldn't get hit, don't call MSDErrorHandler() if there is no error
			break;
	}			
}	

#endif
