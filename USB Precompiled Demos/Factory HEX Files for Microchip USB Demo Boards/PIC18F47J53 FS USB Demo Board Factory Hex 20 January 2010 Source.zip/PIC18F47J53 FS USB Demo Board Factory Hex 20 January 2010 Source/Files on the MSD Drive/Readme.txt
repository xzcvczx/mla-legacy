In this demo, the PIC18F47J53 is presenting itself as two separate 
USB devices (composite device) to the host.  The first device is 
the MSD drive that this file is located on.  The internal flash of 
the microcontroller is being used as the physical media to store the
files.  

The second device is a custom HID device.  This allows applications
to send custom data over the USB bus at up to 64KB/s without having
to install a driver.  There is an example PC application that shows
how to communicate to the HID device.  This application,
"HID PnP Demo Composite HID+MSD Demo only (PID=0x0054).exe" is located
both on the CD that you received and on the MSD drive that appeared
when you plugged in this device.

This demo application allows you to modify the state of the LEDs on
the board as well as monitor the state of the RB2 pushbutton.  It
also provides you a visual representation of the potentiometer if you
have this board attached to the PIC18 Explorer Board (DM183032).

If you have questions about this demo or have questions about how to
get any other USB demos working on this board, please contact:
David Flowers by email at David.Flowers@Microchip.com or by phone at
480-792-7251.
